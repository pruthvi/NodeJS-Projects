const express = require('express');
const router = express.Router();
const bodyparser = require('body-parser');
const urlencodedparser = bodyparser.urlencoded({extended:false});
const task = require('../controllers/task.controller');

//chaining 
router.route('/add').post(urlencodedparser, task.insert)
.get(task.taskadd);

router.route('/').get(task.home);

router.route('/update/:taskId').post(urlencodedparser, task.taskupdate)
.put(task.taskupdate)
router.param('taskId', task.taskupdate);

/*
    router.route('/update/:taskId')
    .get(task.read)
    .put(task.update)
    router.param('taskId', task.taskupdate); 
}
*/




router.get('/list', task.findall);

module.exports = router;
