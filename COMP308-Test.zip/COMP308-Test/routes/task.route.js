const express = require('express');
const router = express.Router();
const bodyparser = require('body-parser');
const urlencodedparser = bodyparser.urlencoded({extended:false});
const task = require('../controllers/task.controller');

//chaining 
router.route('/add').post(urlencodedparser, task.insert)
.get(task.taskadd);

router.route('/').get(task.home);

router.get('/list', task.findall);

module.exports = router;