const taskmodel = require("../model/task.model");

const home = function (req, res) {
  const ret = {};
  res.render("task_home", { data: ret });
}

const taskadd = function (req, res) {
  const ret = {};
  res.render("task_add", { data: ret });
}
const insert = function (req, res) {
  const ret = {};
  taskmodel.create(req.body, function (err, retobj) {
    if (err) {
      ret.msg = err.message;
      res.json({ ret });
    } else {
      res.render("task_home", { data: ret });
    }
  });

}


const findall = function (req, res) {
  taskmodel.find({}, function (err, retobj) {
    let ret = {};
    ret.tasks = retobj;
    res.render("task_list", { data: ret });
  });
}


module.exports = { "insert": insert, "findall": findall,  "home": home, "taskadd": taskadd }
