const mongoose = require('mongoose');
const schema = mongoose.Schema;


const taskschema = new schema({
    taskId:{
       type:String,
       required: true, 
       unique:true,
       minlength:3
   },
   taskName:{
       type:String,
       required:true,
       minlength:5
   },
   taskPriority:{
       type: Number,
       required: true
     },
   taskDescription:{
       type:String,
       maxlength:50
    }
});


module.exports=mongoose.model("task", taskschema);
